//package pacman.model.factories;
//
//import javafx.scene.image.Image;
//import pacman.ConfigurationParseException;
//import pacman.model.entity.Renderable;
//import pacman.model.entity.dynamic.ghost.GhostImpl;
//import pacman.model.entity.dynamic.ghost.GhostMode;
//import pacman.model.entity.dynamic.physics.*;
//
//import java.util.Arrays;
//import java.util.List;
//
///**
// * Concrete renderable factory for Ghost objects
// */
//public class GhostFactory implements RenderableFactory {
//
//    private static final int RIGHT_X_POSITION_OF_MAP = 448;
//    private static final int TOP_Y_POSITION_OF_MAP = 16 * 3;
//    private static final int BOTTOM_Y_POSITION_OF_MAP = 16 * 34;
//
//    private static final Image BLINKY_IMAGE = new Image("maze/ghosts/blinky.png");
//    private static final Image INKY_IMAGE = new Image("maze/ghosts/inky.png");
//    private static final Image CLYDE_IMAGE = new Image("maze/ghosts/clyde.png");
//    private static final Image PINKY_IMAGE = new Image("maze/ghosts/pinky.png");
//    private static final Image GHOST_IMAGE = BLINKY_IMAGE;
//    List<Vector2D> targetCorners = Arrays.asList(
//            new Vector2D(0, TOP_Y_POSITION_OF_MAP),
//            new Vector2D(RIGHT_X_POSITION_OF_MAP, TOP_Y_POSITION_OF_MAP),
//            new Vector2D(0, BOTTOM_Y_POSITION_OF_MAP),
//            new Vector2D(RIGHT_X_POSITION_OF_MAP, BOTTOM_Y_POSITION_OF_MAP)
//    );
//
//    private int getRandomNumber(int min, int max) {
//        return (int) ((Math.random() * (max - min)) + min);
//    }
//
//    @Override
//    public Renderable createRenderable(
//            Vector2D position
//    ) {
//        try {
//            position = position.add(new Vector2D(4, -4));
//
//            BoundingBox boundingBox = new BoundingBoxImpl(
//                    position,
//                    GHOST_IMAGE.getHeight(),
//                    GHOST_IMAGE.getWidth()
//            );
//
//            KinematicState kinematicState = new KinematicStateImpl.KinematicStateBuilder()
//                    .setPosition(position)
//                    .build();
//
//            return new GhostImpl(
//                    GHOST_IMAGE,
//                    boundingBox,
//                    kinematicState,
//                    GhostMode.SCATTER,
//                    targetCorners.get(getRandomNumber(0, targetCorners.size() - 1)));
//        } catch (Exception e) {
//            throw new ConfigurationParseException(
//                    String.format("Invalid ghost configuration | %s ", e));
//        }
//    }
//
//
//}

package pacman.model.factories;

import javafx.scene.image.Image;
import pacman.ConfigurationParseException;
import pacman.model.entity.Renderable;
import pacman.model.entity.dynamic.ghost.Ghost;
import pacman.model.entity.dynamic.ghost.GhostMode;
import pacman.model.entity.dynamic.ghost.concreteghosts.*;
import pacman.model.entity.dynamic.ghost.strategy.*;
import pacman.model.entity.dynamic.physics.*;

public class GhostFactory implements RenderableFactory {

    private static final int TILE_SIZE = 16;
    private static final int RIGHT_X_POSITION_OF_MAP = TILE_SIZE * 28;
    private static final int LEFT_X_POSITION_OF_MAP = 0;
    private static final int TOP_Y_POSITION_OF_MAP = TILE_SIZE * 3;
    private static final int BOTTOM_Y_POSITION_OF_MAP = TILE_SIZE * 34;

    private final char ghostType;


    private static final Image BLINKY_IMAGE = new Image(
            GhostFactory.class.getResource("/maze/ghosts/blinky.png").toExternalForm()
    );
    private static final Image PINKY_IMAGE = new Image(
            GhostFactory.class.getResource("/maze/ghosts/pinky.png").toExternalForm()
    );
    private static final Image INKY_IMAGE = new Image(
            GhostFactory.class.getResource("/maze/ghosts/inky.png").toExternalForm()
    );
    private static final Image CLYDE_IMAGE = new Image(
            GhostFactory.class.getResource("/maze/ghosts/clyde.png").toExternalForm()
    );


    public GhostFactory(char ghostType) { this.ghostType = ghostType; }

    @Override
    public Renderable createRenderable(Vector2D position) {
        try {
            position = position.add(new Vector2D(4, -4));

            switch (ghostType) {
                case RenderableType.BLINKY:
                    return createBlinky(position);
                case RenderableType.PINKY:
                    return createPinky(position);
                case RenderableType.INKY:
                    return createInky(position);
                case RenderableType.CLYDE:
                    return createClyde(position);
                default:
                    throw new IllegalStateException("Unexpected ghost type: " + ghostType);
            }
        } catch (Exception e) {
            throw new ConfigurationParseException(
                    String.format("Invalid ghost configuration | %s ", e));
        }
    }

    // methods broken down
    private Ghost createBlinky(Vector2D position) {
        Vector2D scatterTarget = new Vector2D(RIGHT_X_POSITION_OF_MAP, TOP_Y_POSITION_OF_MAP);

        BoundingBox boundingBox = new BoundingBoxImpl(position, BLINKY_IMAGE.getWidth(), BLINKY_IMAGE.getHeight());

        KinematicState kinematicState = new KinematicStateImpl.KinematicStateBuilder().setPosition(position).build();

        Blinky blinky = new Blinky(BLINKY_IMAGE, boundingBox, kinematicState, GhostMode.SCATTER, scatterTarget);

        blinky.setChaseStrategy(new BlinkyChaseStrategy());

        return blinky;
    }

    private Ghost createClyde(Vector2D position) {
        Vector2D scatterTarget = new Vector2D(LEFT_X_POSITION_OF_MAP, BOTTOM_Y_POSITION_OF_MAP);

        BoundingBox boundingBox = new BoundingBoxImpl(position, CLYDE_IMAGE.getWidth(), CLYDE_IMAGE.getHeight());

        KinematicState kinematicState = new KinematicStateImpl.KinematicStateBuilder() .setPosition(position).build();

        Clyde clyde = new Clyde(CLYDE_IMAGE, boundingBox, kinematicState, GhostMode.SCATTER, scatterTarget);

        clyde.setChaseStrategy(new ClydeChaseStrategy());

        return clyde;
    }

    private Ghost createInky(Vector2D position) {
        Vector2D scatterTarget = new Vector2D(RIGHT_X_POSITION_OF_MAP, BOTTOM_Y_POSITION_OF_MAP);

        BoundingBox boundingBox = new BoundingBoxImpl( position, INKY_IMAGE.getWidth(), INKY_IMAGE.getHeight());

        KinematicState kinematicState = new KinematicStateImpl.KinematicStateBuilder().setPosition(position).build();

        Inky inky = new Inky( INKY_IMAGE, boundingBox, kinematicState, GhostMode.SCATTER, scatterTarget);

        inky.setChaseStrategy(new InkyChaseStrategy());

        return inky;
    }

    private Ghost createPinky(Vector2D position) {
        Vector2D scatterTarget = new Vector2D(LEFT_X_POSITION_OF_MAP, TOP_Y_POSITION_OF_MAP);

        BoundingBox boundingBox = new BoundingBoxImpl(position, PINKY_IMAGE.getWidth(), PINKY_IMAGE.getHeight());

        KinematicState kinematicState = new KinematicStateImpl.KinematicStateBuilder().setPosition(position).build();

        Pinky pinky = new Pinky(PINKY_IMAGE, boundingBox, kinematicState, GhostMode.SCATTER, scatterTarget);

        pinky.setChaseStrategy(new PinkyChaseStrategy());

        return pinky;
    }




}

