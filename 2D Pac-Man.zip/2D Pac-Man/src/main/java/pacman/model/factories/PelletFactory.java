package pacman.model.factories;

import javafx.scene.image.Image;
import pacman.ConfigurationParseException;
import pacman.model.entity.Renderable;
import pacman.model.entity.dynamic.physics.BoundingBox;
import pacman.model.entity.dynamic.physics.BoundingBoxImpl;
import pacman.model.entity.dynamic.physics.Vector2D;
import pacman.model.entity.staticentity.collectable.Pellet;
import pacman.model.entity.staticentity.collectable.PowerPellet;

/**
 * Concrete renderable factory for Pellet objects
 */
public class PelletFactory implements RenderableFactory {
    private static final Image PELLET_IMAGE = new Image("maze/pellet.png");
    private static final int NUM_POINTS = 100;
    private final Renderable.Layer layer = Renderable.Layer.BACKGROUND;

    private static final int POWER_PELLET_POINTS = 100; // asumming its the same

    private final char pelletType;

    public PelletFactory(char pelletType) {
        this.pelletType = pelletType;
    }


    @Override
    public Renderable createRenderable(Vector2D position) {
        try {
            BoundingBox boundingBox;
            if (pelletType == RenderableType.POWER) {
                position = position.add(new Vector2D(-8, -8));
                boundingBox = new BoundingBoxImpl(
                        position,
                        PELLET_IMAGE.getHeight() * 2, // double the size of regular
                        PELLET_IMAGE.getWidth() * 2
                );
                return new PowerPellet(
                        boundingBox,
                        layer,
                        PELLET_IMAGE,
                        POWER_PELLET_POINTS
                );
            } else {
                boundingBox = new BoundingBoxImpl(
                        position,
                        PELLET_IMAGE.getHeight(),
                        PELLET_IMAGE.getWidth()
                );

                return new Pellet(
                        boundingBox,
                        layer,
                        PELLET_IMAGE,
                        NUM_POINTS
                );
            }

        } catch (Exception e) {
            throw new ConfigurationParseException(
                    String.format("Invalid pellet configuration | %s", e));
        }
    }
}

