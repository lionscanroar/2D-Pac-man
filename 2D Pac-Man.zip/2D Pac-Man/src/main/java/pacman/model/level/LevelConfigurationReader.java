package pacman.model.level;

import org.json.simple.JSONObject;
import pacman.model.entity.dynamic.ghost.GhostMode;

import java.util.HashMap;
import java.util.Map;

/**
 * Helper class to read JSONObject to retrieve level configuration details
 */
public class LevelConfigurationReader {

    private final JSONObject levelConfiguration;
    private static final double TICKS_PER_SECOND = 1000.0 / 33.3; // approx 30 ticks is a second


    public LevelConfigurationReader(JSONObject levelConfiguration) {
        this.levelConfiguration = levelConfiguration;
    }

    /**
     * Retrieves the player's speed for the level
     *
     * @return the player's speed for the level
     */
    public double getPlayerSpeed() {
        return ((Number) levelConfiguration.get("pacmanSpeed")).doubleValue();
    }

    /**
     * Retrieves the lengths of the ghost modes in seconds
     *
     * @return the lengths of the ghost modes in seconds
     */
    public Map<GhostMode, Integer> getGhostModeLengths() {
        Map<GhostMode, Integer> ghostModeLengths = new HashMap<>();
        JSONObject modeLengthsObject = (JSONObject) levelConfiguration.get("modeLengths");

        int chaseLengthInSeconds = ((Number) modeLengthsObject.get("chase")).intValue();
        int scatterLengthInSeconds = ((Number) modeLengthsObject.get("scatter")).intValue();

        int chaseLengthInTicks = (int) Math.round(chaseLengthInSeconds * TICKS_PER_SECOND);
        int scatterLengthInTicks = (int) Math.round(scatterLengthInSeconds * TICKS_PER_SECOND);

        ghostModeLengths.put(GhostMode.CHASE, chaseLengthInTicks);
        ghostModeLengths.put(GhostMode.SCATTER, scatterLengthInTicks);


        return ghostModeLengths;
    }

    /**
     * Retrieves the length of the frightened mode in ticks
     *
     * @return the length of the frightened mode in ticks
     */
    public int getFrightenedModeLength() {
        JSONObject modeLengthsObject = (JSONObject) levelConfiguration.get("modeLengths");
        int frightenedLengthInSeconds = ((Number) modeLengthsObject.get("frightened")).intValue();
        return (int) Math.round(frightenedLengthInSeconds * TICKS_PER_SECOND);
    }

    /**
     * Retrieves the speeds of the ghosts for each ghost mode
     *
     * @return the speeds of the ghosts for each ghost mode
     */
    public Map<GhostMode, Double> getGhostSpeeds() {
        Map<GhostMode, Double> ghostSpeeds = new HashMap<>();
        JSONObject ghostSpeed = (JSONObject) levelConfiguration.get("ghostSpeed");
        ghostSpeeds.put(GhostMode.CHASE, ((Number) ghostSpeed.get("chase")).doubleValue());
        ghostSpeeds.put(GhostMode.SCATTER, ((Number) ghostSpeed.get("scatter")).doubleValue());
        ghostSpeeds.put(GhostMode.FRIGHTENED, (Double) ghostSpeed.get("frightened")); // Add this line
        return ghostSpeeds;
    }


}


