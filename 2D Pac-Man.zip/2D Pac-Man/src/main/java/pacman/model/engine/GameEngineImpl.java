package pacman.model.engine;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import pacman.model.engine.observer.GameState;
import pacman.model.engine.observer.GameStateObserver;
import pacman.model.entity.Renderable;
import pacman.model.entity.dynamic.ghost.Ghost;
import pacman.model.entity.dynamic.ghost.GhostImpl;
import pacman.model.entity.dynamic.ghost.concreteghosts.Blinky;
import pacman.model.entity.dynamic.ghost.concreteghosts.Inky;
import pacman.model.entity.dynamic.physics.Direction;
import pacman.model.entity.dynamic.player.Pacman;
import pacman.model.factories.*;
import pacman.model.level.Level;
import pacman.model.level.LevelImpl;
import pacman.model.level.observer.LevelStateObserver;
import pacman.model.maze.Maze;
import pacman.model.maze.MazeCreator;
import pacman.view.keyboard.command.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Implementation of GameEngine - responsible for coordinating the Pac-Man model
 */
public class GameEngineImpl implements GameEngine {

    private final RenderableFactoryRegistry renderableFactoryRegistry;
    private final List<GameStateObserver> observers;
    private final List<LevelStateObserver> levelStateObservers;
    private Level currentLevel;
    private int numLevels;
    private int currentLevelNo;
    private Maze maze;
    private JSONArray levelConfigs;
    private GameState gameState;

    public GameEngineImpl(String configPath) {
        this.renderableFactoryRegistry = getRenderableFactoryRegistry();
        this.currentLevelNo = 0;
        this.observers = new ArrayList<>();
        this.levelStateObservers = new ArrayList<>();

        init(new GameConfigurationReader(configPath));
    }

    private RenderableFactoryRegistry getRenderableFactoryRegistry() {
        RenderableFactoryRegistry renderableFactoryRegistry = new RenderableFactoryRegistryImpl();
        renderableFactoryRegistry.registerFactory(RenderableType.HORIZONTAL_WALL, new WallFactory(RenderableType.HORIZONTAL_WALL));
        renderableFactoryRegistry.registerFactory(RenderableType.VERTICAL_WALL, new WallFactory(RenderableType.VERTICAL_WALL));
        renderableFactoryRegistry.registerFactory(RenderableType.UP_LEFT_WALL, new WallFactory(RenderableType.UP_LEFT_WALL));
        renderableFactoryRegistry.registerFactory(RenderableType.UP_RIGHT_WALL, new WallFactory(RenderableType.UP_RIGHT_WALL));
        renderableFactoryRegistry.registerFactory(RenderableType.DOWN_LEFT_WALL, new WallFactory(RenderableType.DOWN_LEFT_WALL));
        renderableFactoryRegistry.registerFactory(RenderableType.DOWN_RIGHT_WALL, new WallFactory(RenderableType.DOWN_RIGHT_WALL));
        renderableFactoryRegistry.registerFactory(RenderableType.PELLET, new PelletFactory(RenderableType.PELLET));
        renderableFactoryRegistry.registerFactory(RenderableType.PACMAN, new PacmanFactory());

        renderableFactoryRegistry.registerFactory(RenderableType.POWER, new PelletFactory(RenderableType.POWER)); // power pellet uses pelletfactor
        renderableFactoryRegistry.registerFactory(RenderableType.BLINKY, new GhostFactory(RenderableType.BLINKY));
        renderableFactoryRegistry.registerFactory(RenderableType.PINKY, new GhostFactory(RenderableType.PINKY));
        renderableFactoryRegistry.registerFactory(RenderableType.INKY, new GhostFactory(RenderableType.INKY));
        renderableFactoryRegistry.registerFactory(RenderableType.CLYDE, new GhostFactory(RenderableType.CLYDE));
        return renderableFactoryRegistry;
    }

    private void init(GameConfigurationReader gameConfigurationReader) {
        // Set up map
        String mapFile = gameConfigurationReader.getMapFile();
        MazeCreator mazeCreator = new MazeCreator(mapFile, renderableFactoryRegistry);
        this.maze = mazeCreator.createMaze();
        this.maze.setNumLives(gameConfigurationReader.getNumLives());

        // Get level configurations
        this.levelConfigs = gameConfigurationReader.getLevelConfigs();
        this.numLevels = levelConfigs.size();
        if (levelConfigs.isEmpty()) {
            System.exit(0);
        }
    }

    @Override
    public List<Renderable> getRenderables() {
        return this.currentLevel.getRenderables();
    }

    @Override
    public void moveUp() {
        currentLevel.moveUp();
    }

    @Override
    public void moveDown() {
        currentLevel.moveDown();
    }

    @Override
    public void moveLeft() {
        currentLevel.moveLeft();
    }

    @Override
    public void moveRight() {
        currentLevel.moveRight();
    }

    @Override
    public void startGame() {
        startLevel();
    }

    private void startLevel() {
        JSONObject levelConfig = (JSONObject) levelConfigs.get(currentLevelNo);
        // Reset renderables to starting state
        this.currentLevel = new LevelImpl(levelConfig, maze);
        maze.reset();

        for (LevelStateObserver observer : this.levelStateObservers) {
            this.currentLevel.registerObserver(observer);
        }

        // Set up references between ghosts and Pac-Man (Blinky
        Pacman pacman = (Pacman) maze.getControllable();

        for (Renderable renderable : maze.getGhosts()) {
            if (renderable instanceof Ghost ghost) {
                ghost.setPacman(pacman);
            }
        }

        // reference for Inky
        Blinky blinky = null;
        Inky inky = null;

        for (Renderable renderable : maze.getGhosts()) {
            if (renderable instanceof Blinky) {
                blinky = (Blinky) renderable;
            } else if (renderable instanceof Inky) {
                inky = (Inky) renderable;
            }
        }
        // Set Blinky reference for inky
        if (inky != null && blinky != null) {
            inky.setBlinky(blinky);
        }
        this.setGameState(GameState.READY);
    }


    @Override
    public void tick() {
        if (currentLevel.getNumLives() == 0) {
            handleGameOver();
            return;
        }

        if (currentLevel.isLevelFinished()) {
            handleLevelEnd();
            return;
        }

        currentLevel.tick();
    }

    private void handleLevelEnd() {
        if (numLevels - 1 == currentLevelNo) {
            handlePlayerWins();
        } else {
            this.currentLevelNo += 1;

            // remove observers
            for (LevelStateObserver observer : this.levelStateObservers) {
                this.currentLevel.removeObserver(observer);
            }

            startLevel();
        }
    }

    private void handleGameOver() {
        if (gameState != GameState.PLAYER_WIN) {
            setGameState(GameState.GAME_OVER);
            currentLevel.handleGameEnd();
        }
    }

    private void handlePlayerWins() {
        if (gameState != GameState.PLAYER_WIN) {
            setGameState(GameState.PLAYER_WIN);
            currentLevel.handleGameEnd();
        }
    }

    private void setGameState(GameState gameState) {
        this.gameState = gameState;
        notifyObserversWithGameState();
    }

    @Override
    public void registerObserver(GameStateObserver observer) {
        this.observers.add(observer);
    }

    @Override
    public void notifyObserversWithGameState() {
        for (GameStateObserver observer : observers) {
            observer.updateGameState(this.gameState);
        }
    }

    @Override
    public void registerLevelStateObserver(LevelStateObserver observer) {
        this.levelStateObservers.add(observer);
    }
}


