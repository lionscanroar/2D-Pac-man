package pacman.model.entity.dynamic.ghost.concreteghosts;

import javafx.scene.image.Image;
import pacman.model.entity.dynamic.ghost.GhostImpl;
import pacman.model.entity.dynamic.ghost.GhostMode;
import pacman.model.entity.dynamic.ghost.strategy.BlinkyChaseStrategy;
import pacman.model.entity.dynamic.physics.*;
import pacman.model.entity.dynamic.player.Pacman;

public class Blinky extends GhostImpl {

    public Blinky(Image image, BoundingBox boundingBox, KinematicState kinematicState, GhostMode ghostMode,
                  Vector2D targetCorner) {

        super(image, boundingBox, kinematicState, ghostMode, targetCorner);
        setChaseStrategy(new BlinkyChaseStrategy());

    }

}

