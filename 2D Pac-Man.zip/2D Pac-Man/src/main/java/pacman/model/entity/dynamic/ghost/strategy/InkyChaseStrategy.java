package pacman.model.entity.dynamic.ghost.strategy;

import pacman.model.entity.dynamic.ghost.Ghost;
import pacman.model.entity.dynamic.physics.Direction;
import pacman.model.entity.dynamic.physics.Vector2D;
import pacman.model.entity.dynamic.player.Pacman;
import pacman.model.maze.MazeCreator;



public class InkyChaseStrategy implements ChaseStrategy {
    @Override
    public void chase(Ghost ghost, Pacman pacman) {

        // Pac-Man's position and direction
        //        double pacmanX = pacman.getPosition().getX();
        //        double pacmanY = pacman.getPosition().getY();
        Direction pacmanDirection = pacman.getDirection();

        // Log Pac-Man's position and direction
        //        System.out.println("Pac-Man's position: (" + pacmanX + ", " + pacmanY + ")");

        Ghost blinky = ghost.getBlinky();

//        if (blinky == null) {
//         System.out.println("Error: Blinky reference is null in Inky's chase strategy.");
//            return;
//        } else {
//         System.out.println("Blinky reference in Inky's chase strategy is set: " + blinky);
//        }

        double blinkyX = blinky.getPosition().getX();
        double blinkyY = blinky.getPosition().getY();
        // System.out.println("Blinky Position: (" + blinkyX + ", " + blinkyY + ")");

        double scale = 2 * MazeCreator.RESIZING_FACTOR;
        Vector2D offset = getDirectionOffset(pacmanDirection, scale);
        Vector2D twoTilesAhead = pacman.getPosition().add(offset);

        double xDistance = twoTilesAhead.getX() - blinkyX;
        double yDistance = twoTilesAhead.getY() - blinkyY;

        double xOffset = xDistance * 2;
        double yOffset = yDistance * 2;

        Vector2D target = new Vector2D(blinkyX + xOffset, blinkyY + yOffset);

        //        System.out.println("Offset: (" + offset.getX() + ", " + offset.getY() + ")");
        //        System.out.println("Two Tiles Ahead: (" + twoTilesAhead.getX() + ", " + twoTilesAhead.getY() + ")");
        //        System.out.println("xDistance: " + xDistance + ", yDistance: " + yDistance);
        //        System.out.println("xOffset: " + xOffset + ", yOffset: " + yOffset);
        //        System.out.println("Inky Target: (" + target.getX() + ", " + target.getY() + ")");

        // Corrected method to set the chase target
        //        ghost.setChaseTarget(target);
        ghost.setChaseTarget(target);

        //        System.out.println("Inky chaseTarget set to: " + ghost.getChaseTarget());
    }


    private Vector2D getDirectionOffset(Direction direction, double scale) {
        double xOffset = 0;
        double yOffset = 0;

        switch (direction) {
            case UP:
                yOffset = -scale;
                break;
            case DOWN:
                yOffset = scale;
                break;
            case LEFT:
                xOffset = -scale;
                break;
            case RIGHT:
                xOffset = scale;
                break;
            default:
                break;
        }

        return new Vector2D(xOffset, yOffset);
    }
}

