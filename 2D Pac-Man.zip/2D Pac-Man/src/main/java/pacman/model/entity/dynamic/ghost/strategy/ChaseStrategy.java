package pacman.model.entity.dynamic.ghost.strategy;

import pacman.model.entity.dynamic.ghost.Ghost;
import pacman.model.entity.dynamic.player.Pacman;

public interface ChaseStrategy {
    void chase(Ghost ghost, Pacman pacman);
}

