package pacman.model.entity.dynamic.ghost.adapter;

import javafx.scene.image.Image;
import javafx.scene.image.WritableImage;
import pacman.model.entity.Renderable;
import pacman.model.entity.dynamic.ghost.Ghost;
import pacman.model.entity.dynamic.ghost.GhostMode;
import pacman.model.entity.dynamic.physics.Direction;
import pacman.model.level.Level;

public class FrightenedGhostAdaptee {
    private boolean isFrightened = false;
    private boolean isEaten = false;
    private int frightenedModeTicks = 0;
    private int frightenedModeDuration = 0;
    private int tickCounter = 0;
    private int respawnWaitTimer = 0;
    private static final int RESPAWN_DELAY_TICKS = 30;
    private final Image normalImage;
    private final Image frightenedImage;
    private final Image transparentImage;


    public FrightenedGhostAdaptee(Image normalImage, Image frightenedImage) {
        this.normalImage = normalImage;
        this.frightenedImage = frightenedImage;
        this.transparentImage = new WritableImage(1, 1); // transparent image for "eaten" state
    }

    public void startFrightenedMode(Ghost ghost, int duration) {
        if (!isFrightened) {
            isFrightened = true;
            frightenedModeDuration = duration;
            frightenedModeTicks = 0;
            ghost.setGhostMode(GhostMode.FRIGHTENED);
            ghost.setImage(frightenedImage);
            // reverse direction
            Direction currentDirection = ghost.getDirection();
            if (currentDirection != null) {
                ghost.setDirection(currentDirection.opposite());
            }
        } else {
            // if already frightened, reset the duration
            frightenedModeDuration = duration;
            frightenedModeTicks = 0;
        }
    }

    public void endFrightenedMode(Ghost ghost) {
        isFrightened = false;
        ghost.setGhostMode(GhostMode.SCATTER);
        ghost.setImage(normalImage);
    }

    public void updateFrightenedState(Ghost ghost) {
        if (isEaten) {
            // increment the respawn delay timer
            tickCounter++;
            if (tickCounter >= RESPAWN_DELAY_TICKS) { // reset the ghost after the delay
                ghost.reset(); // reset ghost's state and position
                isEaten = false;
                tickCounter = 0;
                respawnWaitTimer = 1; // Start the respawn wait timer
            }
        } else if (respawnWaitTimer > 0) {
            respawnWaitTimer++;
            if (respawnWaitTimer > RESPAWN_DELAY_TICKS) {
                respawnWaitTimer = 0;
                // sestore the ghost's mode
                ghost.setGhostMode(GhostMode.SCATTER); // reset when eaten
                ghost.setImage(normalImage);
                // speed is set in setGhostMode
            } else {
                // while waiting, keep the ghost still by freezing
                ghost.setKinematicStateSpeed(0);
            }
        } else {
            // frighten behavior when the ghost is not in the waiting state
            if (isFrightened) {
                frightenedModeTicks++;
                if (frightenedModeTicks >= frightenedModeDuration) {
                    endFrightenedMode(ghost); // End frightened mode
                }
            }
        }
    }

    public void resetFrightenedState(Ghost ghost) {
        isFrightened = false;
        frightenedModeTicks = 0;
        frightenedModeDuration = 0;
        isEaten = false;
        tickCounter = 0;
        respawnWaitTimer = 0; // Reset the respawn wait timer
    }

    //    added && !isEaten to the condition to ensure that the collision handling code only runs
    //    if the ghost has not already been eaten. prevents level.handleGhostEaten() from being called multiple times
    //    for the same ghost before it respawns.
    //    avoid multiple increments of ghostsEatenInCurrentFrightenedMode from a single ghost.
    public void collideWith(Level level, Ghost ghost, Renderable renderable) {
        // collision isEaten = true level triggers level adding points
            if (level.isPlayer(renderable) && !isEaten) {
                if (isFrightened) {
                isEaten = true; // Mark the ghost as eaten
                ghost.setImage(transparentImage); // Hide the ghost
                level.handleGhostEaten(ghost); // Notify the level
                tickCounter = 0; // reset the tick counter
            } else {
                level.handleLoseLife();
            }
        }
    }

    public boolean isFrightened() {
        return isFrightened;
    }

    public boolean isEaten() {
        return isEaten;
    }

}
