package pacman.model.entity.dynamic.ghost.adapter;

import pacman.model.entity.Renderable;
import pacman.model.entity.dynamic.ghost.Ghost;
import pacman.model.entity.dynamic.ghost.GhostMode;
import pacman.model.level.Level;

public interface FrightenedGhostBehaviour {
    void startFrightenedMode(Ghost ghost, int duration);

    void endFrightenedMode(Ghost ghost);

    void updateFrightenedState(Ghost ghost);

    void collideWith(Level level, Ghost ghost, Renderable renderable);

    void resetFrightenedState(Ghost ghost);

    boolean isFrightened();

    boolean isEaten();
}


