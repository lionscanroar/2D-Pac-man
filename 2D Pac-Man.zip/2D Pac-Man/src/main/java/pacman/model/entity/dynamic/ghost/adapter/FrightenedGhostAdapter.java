package pacman.model.entity.dynamic.ghost.adapter;

import pacman.model.entity.Renderable;
import pacman.model.entity.dynamic.ghost.Ghost;
import pacman.model.entity.dynamic.ghost.GhostMode;
import pacman.model.level.Level;

public class FrightenedGhostAdapter implements FrightenedGhostBehaviour {
    private final FrightenedGhostAdaptee adaptee;

    public FrightenedGhostAdapter(FrightenedGhostAdaptee adaptee) {
        this.adaptee = adaptee;
    }

    @Override
    public void startFrightenedMode(Ghost ghost, int duration) {
        adaptee.startFrightenedMode(ghost, duration);
    }

    @Override
    public void endFrightenedMode(Ghost ghost) {
        adaptee.endFrightenedMode(ghost);
    }

    @Override
    public void updateFrightenedState(Ghost ghost) {
        adaptee.updateFrightenedState(ghost);
    }

    @Override
    public void collideWith(Level level, Ghost ghost, Renderable renderable) {
        adaptee.collideWith(level, ghost, renderable);
    }

    @Override
    public void resetFrightenedState(Ghost ghost) {
        adaptee.resetFrightenedState(ghost);
    }

    @Override
    public boolean isFrightened() {
        return adaptee.isFrightened();
    }

    @Override
    public boolean isEaten() {
        return adaptee.isEaten();
    }
}
