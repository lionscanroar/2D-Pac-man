package pacman.model.entity.dynamic.ghost.strategy;

import pacman.model.entity.dynamic.DynamicEntity;
import pacman.model.entity.dynamic.ghost.Ghost;
import pacman.model.entity.dynamic.physics.Direction;
import pacman.model.entity.dynamic.physics.Vector2D;
import pacman.model.entity.dynamic.player.Pacman;
import pacman.model.maze.MazeCreator;

public class PinkyChaseStrategy implements ChaseStrategy {
    @Override
    public void chase(Ghost ghost, Pacman pacman) {
        int tileSize = 16; // Assuming each tile is 16 pixels

        // Pac-Man's position and direction
        double pacmanX = pacman.getPosition().getX();
        double pacmanY = pacman.getPosition().getY();
        Direction pacmanDirection = pacman.getDirection();

        // Log Pac-Man's position and direction
        // System.out.println("Pac-Man's position: (" + pacmanX + ", " + pacmanY + ")");
        //  System.out.println("Pac-Man's direction: " + pacmanDirection);

        // Calculate the point four tiles ahead of Pac-Man
        double offsetX = 0;
        double offsetY = 0;
        switch (pacmanDirection) {
            case UP:
                offsetY = -4 * tileSize;
                break;
            case DOWN:
                offsetY = 4 * tileSize;
                break;
            case LEFT:
                offsetX = -4 * tileSize;
                break;
            case RIGHT:
                offsetX = 4 * tileSize;
                break;
            default:
                break;
        }
        double targetX = pacmanX + offsetX;
        double targetY = pacmanY + offsetY;

        // Log Pinky's target position
        // System.out.println("Pinky's calculated target: (" + targetX + ", " + targetY + ")");

        // Set the chase target
        ghost.setChaseTarget(new Vector2D(targetX, targetY));
    }
}

