package pacman.model.entity.dynamic.ghost;

import javafx.scene.image.Image;
import pacman.model.entity.Renderable;
import pacman.model.entity.dynamic.ghost.adapter.FrightenedGhostAdaptee;
import pacman.model.entity.dynamic.ghost.adapter.FrightenedGhostAdapter;
import pacman.model.entity.dynamic.ghost.adapter.FrightenedGhostBehaviour;
import pacman.model.entity.dynamic.ghost.strategy.ChaseStrategy;
import pacman.model.entity.dynamic.physics.*;
        import pacman.model.entity.dynamic.player.Pacman;
import pacman.model.level.Level;
import pacman.model.maze.Maze;

import java.util.*;

/**
 * Concrete implementation of Ghost entity in Pac-Man Game
 */
public class GhostImpl implements Ghost {

    private static final int minimumDirectionCount = 8;
    private final Renderable.Layer layer = Renderable.Layer.FOREGROUND;
    private Image image;
    private final BoundingBox boundingBox;
    private final Vector2D startingPosition;
    private final Vector2D targetCorner;
    private KinematicState kinematicState;
    private GhostMode ghostMode;
    private Vector2D targetLocation;
    private Vector2D playerPosition;
    private Direction currentDirection;
    private Set<Direction> possibleDirections;
    private Map<GhostMode, Double> speeds;
    private int currentDirectionCount = 0;

    // fields for chase
    private final FrightenedGhostBehaviour frightenedBehavior;
    private ChaseStrategy chaseStrategy;
    private Vector2D chaseTarget; // for chase strategy

    // fields for frighten
    protected Ghost blinky;
    protected Pacman pacman; // for inky
    private final Image normalImage;
    private final Image frightenedImage;

    public GhostImpl(Image image, BoundingBox boundingBox, KinematicState kinematicState, GhostMode ghostMode,
                     Vector2D targetCorner) {
        this.boundingBox = boundingBox;
        this.kinematicState = kinematicState;
        this.startingPosition = kinematicState.getPosition();
        this.ghostMode = ghostMode;
        this.possibleDirections = new HashSet<>();
        this.targetCorner = targetCorner;
        this.targetLocation = getTargetLocation();

        // frighten
        this.normalImage = image;
        this.frightenedImage = new Image("maze/ghosts/frightened.png");
        this.image = normalImage;
        this.kinematicState.setSpeed(0);
        // Init the frightened behavior
        this.frightenedBehavior = new FrightenedGhostAdapter(new FrightenedGhostAdaptee(normalImage, frightenedImage));
    }


    @Override
    public void setSpeeds(Map<GhostMode, Double> speeds) { this.speeds = speeds;}

    @Override
    public Image getImage() { return image; }

//    Added a check for !isEaten() to ensure that the ghost does not move or update its position when it has been eaten.
//    Prevents the ghost from moving around the map after being eaten, which could cause unintended interactions.
//    This ensures that the ghost remains inactive until it has fully respawned.
    @Override
    public void update() {
        // Update frightened state
        frightenedBehavior.updateFrightenedState(this);

        // If the ghost is not eaten and has positive speed, update movement
        if (!frightenedBehavior.isEaten() && kinematicState.getSpeed() > 0) {
            if (this.ghostMode == GhostMode.CHASE) {
                this.chase(this.pacman);
            }
            this.updateDirection();
            this.kinematicState.update();
            this.boundingBox.setTopLeft(this.kinematicState.getPosition());
        }
    }

    private void updateDirection() {
        // Ghosts update their target location when they reach an intersection
        if (Maze.isAtIntersection(this.possibleDirections)) {
            this.targetLocation = getTargetLocation();
        }

        Direction newDirection = selectDirection(possibleDirections);

        // Ghosts have to continue in a direction for a minimum time before changing direction
        if (this.currentDirection != newDirection) {
            this.currentDirectionCount = 0;
        }
        this.currentDirection = newDirection;

        switch (currentDirection) {
            case LEFT -> this.kinematicState.left();
            case RIGHT -> this.kinematicState.right();
            case UP -> this.kinematicState.up();
            case DOWN -> this.kinematicState.down();
        }
    }

    // Implemented chase target
    // FRIGHTEN -> placeholder
    private Vector2D getTargetLocation() {
        return switch (this.ghostMode) {
            case CHASE -> this.chaseTarget != null ? this.chaseTarget : this.playerPosition;
            case SCATTER -> this.targetCorner;
            case FRIGHTENED -> this.targetCorner;
        };
    }

    // Frighten mode random selection movement
    private Direction selectDirection(Set<Direction> possibleDirections) {
        if (possibleDirections.isEmpty()) {
            return currentDirection;
        }

        if (ghostMode == GhostMode.FRIGHTENED) {
            // Random movement logic
            List<Direction> directions = new ArrayList<>(possibleDirections);
            if (currentDirection != null) {
                directions.remove(currentDirection.opposite());
            }
            if (directions.isEmpty()) {
                return currentDirection.opposite();
            }
            return directions.get(new Random().nextInt(directions.size()));
        }

        // ghosts have to continue in a direction for a minimum time before changing direction
        if (currentDirection != null && currentDirectionCount < minimumDirectionCount) {
            currentDirectionCount++;
            return currentDirection;
        }

        Map<Direction, Double> distances = new HashMap<>();

        for (Direction direction : possibleDirections) {
            // ghosts never choose to reverse travel
            if (currentDirection == null || direction != currentDirection.opposite()) {
                distances.put(direction, Vector2D.calculateEuclideanDistance(this.kinematicState.getPotentialPosition(direction), this.targetLocation));
            }
        }

        // only go the opposite way if trapped
        if (distances.isEmpty()) {
            return currentDirection.opposite();
        }

        // select the direction that will reach the target location fastest
        return Collections.min(distances.entrySet(), Map.Entry.comparingByValue()).getKey();
    }

    // Freeze speed once ghost mode changes
    @Override
    public void setGhostMode(GhostMode ghostMode) {
        this.ghostMode = ghostMode;
        if (speeds != null && speeds.containsKey(ghostMode)) {
            double newSpeed = speeds.get(ghostMode);
            this.kinematicState.setSpeed(newSpeed);


    //            System.out.println("Ghost mode set to " + ghostMode + " with speed " + newSpeed);
        } else {
    //            System.err.println("Speeds not defined for mode: " + ghostMode);
            this.kinematicState.setSpeed(0.5);
        }
        // ensure direction is switched
        this.currentDirectionCount = minimumDirectionCount;
    }


    //    // before
    //    @Override
    //    public boolean collidesWith(Renderable renderable) {
    //        return boundingBox.collidesWith(kinematicState.getSpeed(), kinematicState.getDirection(), renderable.getBoundingBox());
    //    }

    //    Added a check to see if the ghost is in the eaten state by calling isEaten().
    //    If the ghost is eaten, collidesWith() returns false, preventing any collision detection with Pac-Man.
    //    This ensures that once a ghost is eaten, it doesn't continue to interact with Pac-Man,
    //    avoiding multiple increments of the counter.
    @Override
    public boolean collidesWith(Renderable renderable) {
        // Prevent collision if the ghost is eaten
        if (this.isEaten()) {
            return false;
        }
        return boundingBox.collidesWith(kinematicState.getSpeed(), kinematicState.getDirection(),
                renderable.getBoundingBox());
    }

    //    adapter will do the handling and call levels
    @Override
    public void collideWith(Level level, Renderable renderable) {
        frightenedBehavior.collideWith(level, this, renderable);
    }

    @Override
    public void update(Vector2D playerPosition) { this.playerPosition = playerPosition; }

    @Override
    public Vector2D getPositionBeforeLastUpdate() { return this.kinematicState.getPreviousPosition(); }

    @Override
    public double getHeight() { return this.boundingBox.getHeight(); }

    @Override
    public double getWidth() { return this.boundingBox.getWidth(); }

    @Override
    public Vector2D getPosition() { return this.kinematicState.getPosition(); }

    @Override
    public void setPosition(Vector2D position) { this.kinematicState.setPosition(position); }

    @Override
    public Layer getLayer() { return this.layer; }

    @Override
    public BoundingBox getBoundingBox() { return this.boundingBox; }


    // No setghostmode here - adapter does this
    // reset normal image of ghost once repawned
    @Override
    public void reset() {
        this.kinematicState = new KinematicStateImpl.KinematicStateBuilder()
                .setPosition(startingPosition)
                .build();
        this.boundingBox.setTopLeft(startingPosition);
        // setGhostMode(GhostMode.SCATTER); // no set GhostMode here; let the adapter handle it
        this.currentDirectionCount = minimumDirectionCount;
        setImage(normalImage);

        frightenedBehavior.resetFrightenedState(this);
    }

    @Override
    public void setPossibleDirections(Set<Direction> possibleDirections) {
        this.possibleDirections = possibleDirections;
    }

    @Override
    public Direction getDirection() { return this.kinematicState.getDirection(); }

    @Override
    public Vector2D getCenter() { return new Vector2D(boundingBox.getMiddleX(), boundingBox.getMiddleY()); }



    // Delegate frightened methods to the adapter

    @Override
    public void startFrightenedMode(int duration) { frightenedBehavior.startFrightenedMode(this, duration); }

    @Override
    public void endFrightenedMode() { frightenedBehavior.endFrightenedMode(this); }

    @Override
    public boolean isFrightened() { return frightenedBehavior.isFrightened(); }

    // Triggers adaptee
    @Override
    public boolean isEaten() { return frightenedBehavior.isEaten(); }

    // reset setspeed to 0; trigger waiting period and delay respawn
    public void setKinematicStateSpeed(double speed) { this.kinematicState.setSpeed(speed); }

    // reset normal image in repawn
    @Override
    public void setImage(Image image) { this.image = image; }

    // For Strategy pattern
    @Override
    public void chase(Pacman pacman) {
        if (chaseStrategy != null) {
            chaseStrategy.chase(this, pacman);
        }
    }

    @Override
    public void setChaseTarget(Vector2D target) { this.chaseTarget = target; }

    // instance for inky
    @Override
    public void setPacman(Pacman pacman) { this.pacman = pacman; }

    @Override
    public Vector2D getScatterTarget() { return this.targetCorner; }

    @Override
    public void setBlinky(Ghost blinky) { this.blinky = blinky; }

    @Override
    public Ghost getBlinky() { return this.blinky; }

    public void setChaseStrategy(ChaseStrategy chaseStrategy) { this.chaseStrategy = chaseStrategy; }

    public void setDirection(Direction direction) { this.currentDirection = direction; }

}



