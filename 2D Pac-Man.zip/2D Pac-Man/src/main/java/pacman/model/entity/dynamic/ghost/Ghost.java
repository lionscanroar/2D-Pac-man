
package pacman.model.entity.dynamic.ghost;

import javafx.scene.image.Image;
import pacman.model.entity.dynamic.DynamicEntity;
import pacman.model.entity.dynamic.physics.Direction;
import pacman.model.entity.dynamic.physics.Vector2D;
import pacman.model.entity.dynamic.player.Pacman;
import pacman.model.entity.dynamic.player.observer.PlayerPositionObserver;

import java.util.Map;

/**
 * Represents Ghost entity in Pac-Man Game
 */
public interface Ghost extends DynamicEntity, PlayerPositionObserver {

    /***
     * Sets the speeds of the Ghost for each GhostMode
     * @param speeds speeds of the Ghost for each GhostMode
     */
    void setSpeeds(Map<GhostMode, Double> speeds);

    /**
     * Sets the mode of the Ghost used to calculate target position
     *
     * @param ghostMode mode of the Ghost
     */
    void setGhostMode(GhostMode ghostMode);

    // for chase mode

    /***
     * Updates the ghost's chase behavior based on Pacman's position
     * @param pacman the Pacman instance
     */
    void chase(Pacman pacman);

    /***
     * Set the ghost's chase target based on Pacman's position
     * @param target the Pacman instance
     */
    void setChaseTarget(Vector2D target);

    /***
     * get the ghost's scatter target
     */
    Vector2D getScatterTarget();

    /***
     * get the ghost's scatter target
     * @param blinky For Inky to get Blinky's location
     */
    void setBlinky(Ghost blinky);

    /***
     * retrieve the blinky reference
     */
    Ghost getBlinky();

    /**
     * Sets the Pac-Man reference for the ghost
     *
     * @param pacman the Pac-Man instance
     */
    void setPacman(Pacman pacman);


    // for frighten

    /***
     * Starts the frightened mode for the ghost for a specified duration.
     * @param duration the duration for frightened mode in game ticks
     */
    void startFrightenedMode(int duration);

    /***
     * Ends the frightened mode, restoring the ghost's default behavior.
     */
    void endFrightenedMode();

    /***
     * Checks if the ghost is in frightened mode.
     * @return true if the ghost is frightened, false otherwise
     */
    boolean isFrightened();

    /***
     * Checks if the ghost has been "eaten" by Pac-Man during frightened mode.
     * @return true if the ghost is eaten, false otherwise
     */
    boolean isEaten();

    /***
     * Sets the visual representation (image) of the ghost.
     * @param image the Image to represent the ghost's current state
     */
    void setImage(Image image);

    /***
     * Sets the speed of the ghost's kinematic state, allowing for dynamic adjustments.
     * @param speed the new speed of the ghost
     */
    void setKinematicStateSpeed(double speed);

    /***
     * Sets the direction of the ghost's movement.
     * @param direction the Direction the ghost should move
     */
    void setDirection(Direction direction);
}



