package pacman.model.entity.dynamic.ghost.strategy;

import pacman.model.entity.dynamic.ghost.Ghost;
import pacman.model.entity.dynamic.physics.Direction;
import pacman.model.entity.dynamic.player.Pacman;

public class BlinkyChaseStrategy implements ChaseStrategy {
    @Override
    public void chase(Ghost ghost, Pacman pacman) {

        // debugger
        // Pac-Man's position and direction
        // double pacmanX = pacman.getPosition().getX();
        // double pacmanY = pacman.getPosition().getY();
        // Direction pacmanDirection = pacman.getDirection();

        // // Log Pac-Man's position and direction
        // System.out.println("Pac-Man's position: (" + pacmanX + ", " + pacmanY + ")");
        // System.out.println("Pac-Man's direction: " + pacmanDirection);
        //
        // ghost.update(pacman.getPosition());
        // System.out.println("Blinky Target set to: " + ghost.getChaseTarget());

        // System.out.println("Blinky Target set to: " + ghost.getChaseTarget());

        ghost.setChaseTarget(pacman.getPosition());
    }
}

