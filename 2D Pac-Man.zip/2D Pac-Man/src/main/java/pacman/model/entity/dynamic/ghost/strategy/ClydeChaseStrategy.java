package pacman.model.entity.dynamic.ghost.strategy;

import pacman.model.entity.dynamic.ghost.Ghost;
import pacman.model.entity.dynamic.physics.Vector2D;
import pacman.model.entity.dynamic.player.Pacman;

public class ClydeChaseStrategy implements ChaseStrategy {
    @Override
    public void chase(Ghost ghost, Pacman pacman) {
        double tileSize = 16.0;

        // Clyde's position
        double ghostX = ghost.getPosition().getX();
        double ghostY = ghost.getPosition().getY();

        // Pac-Man's position
        double pacmanX = pacman.getPosition().getX();
        double pacmanY = pacman.getPosition().getY();

        // Log Pac-Man's position and direction
        //        System.out.println("Pac-Man's position: (" + pacmanX + ", " + pacmanY + ")");
        //        System.out.println("Pac-Man's direction: " + pacmanDirection);


        // Compute Euclidean distance
        double distance = Vector2D.calculateEuclideanDistance(
                new Vector2D(ghostX, ghostY),
                new Vector2D(pacmanX, pacmanY)
        );

        double thresholdDistance = 8.0 * tileSize; // 128 pixels

        if (distance > thresholdDistance) {
            ghost.setChaseTarget(new Vector2D(pacmanX, pacmanY));
        // System.out.println("Clyde is far; chaseTarget set to Pac-Man at " + ghost.getChaseTarget());
        }
        else {
            ghost.setChaseTarget(ghost.getScatterTarget());
        // System.out.println("Clyde is close; chaseTarget set to scatter corner at " + ghost.getChaseTarget());
        }
    }
}


