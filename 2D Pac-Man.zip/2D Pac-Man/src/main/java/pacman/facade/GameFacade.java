package pacman.facade;

import javafx.scene.Scene;
import pacman.model.engine.GameEngine;
import pacman.model.engine.GameEngineImpl;
import pacman.view.GameWindow;

public class GameFacade {
    private final GameEngine gameEngine;
    private final GameWindow gameWindow;

    public GameFacade(String configPath, int width, int height) {
        gameEngine = new GameEngineImpl(configPath);
        gameWindow = new GameWindow(gameEngine, width, height);
    }

    public Scene getScene() {
        return gameWindow.getScene();
    }

    public void startGame() {
        gameWindow.run();
    }
}

