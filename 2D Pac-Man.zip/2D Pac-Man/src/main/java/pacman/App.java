package pacman;

import javafx.application.Application;
import javafx.stage.Stage;
import pacman.facade.GameFacade;


public class App extends Application {

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        GameFacade gameFacade = new GameFacade("src/main/resources/config.json", 448, 576);
        // Facade implementation
        primaryStage.setTitle("Pac-Man");
        primaryStage.setScene(gameFacade.getScene());
        primaryStage.show();

        gameFacade.startGame();
    }
}





